package com.manvirsingh.popularmovies;

import com.manvirsingh.popularmovies.MovieAttributes.MovieAttributes;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MovieAPI {

    String BASE_URL="https://api.themoviedb.org/";

    @GET("/3/discover/movie?sort_by=popularity.desc&api_key=652f215200fe98dd39d7259b5be7deac")
    Call<MovieAttributes> getData();


}
