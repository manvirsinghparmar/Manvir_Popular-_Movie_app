package com.manvirsingh.popularmovies;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Movie;
import android.net.Uri;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.manvirsingh.popularmovies.MovieAttributes.MovieAttributes;
import com.manvirsingh.popularmovies.MovieAttributes.Results;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private final static String BASE_URL = "https://api.themoviedb.org/";
    private static final String MOVIES_SAVED = "movies";

    private GridView gridView;

    private ProgressBar progressBar;
    private TextView ErrorMessageDisplay;
    private GridViewAdapter mGridAdapter;

   ArrayList<Results> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: MSP- On create Started");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = (GridView) findViewById(R.id.main_grid_View);
        progressBar = (ProgressBar) findViewById(R.id.main_progressbar);
        ErrorMessageDisplay = (TextView) findViewById(R.id.error_message);

        if (savedInstanceState == null)

        {
            Retrofit retrofit = new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();

            final MovieAPI movieAPI = retrofit.create(MovieAPI.class);

            Call<MovieAttributes> call = movieAPI.getData();

            progressBar.setVisibility(View.VISIBLE);

            call.enqueue(new Callback<MovieAttributes>() {
                @Override
                public void onResponse(Call<MovieAttributes> call, Response<MovieAttributes> response) {

                    //Log for checking Server Response
                    Log.d(TAG, "onResponse: MSP-On Server Responce:" + response.toString());

                    //Log for checking the data obtained upon sucessfull connection
                    Log.d(TAG, "onResponse: MSP- On Server Response:" + response.body().toString());


                    final ArrayList<Results> list = response.body().getResult();

                    progressBar.setVisibility(View.INVISIBLE);

                    for (int i = 0; i < list.size(); i++) {
                        Log.d(TAG, "onResponse: \n" + "title:" + list.get(i).getTitle() + "\n"
                                + "Popularity:" + list.get(i).getPopularity() + "\n"
                                + "Release Date: " + list.get(i).getRelease_date() + "\n"
                                + "Poster Path:" + list.get(i).getPoster_path() + "\n"
                                + "Over View:" + list.get(i).getOverview() + "\n\n\n"
                        );

                        mGridAdapter = new GridViewAdapter(MainActivity.this, R.layout.layout_for_grid, list);
                        gridView.setAdapter(mGridAdapter);
                    }
                    setdata();

                }

                @Override
                public void onFailure(Call<MovieAttributes> call, Throwable t) {
                    Log.d(TAG, "onFailure: MSP- ON FAILURE: " + t.getMessage());

                    showErrorMessage();
                    progressBar.setVisibility(View.INVISIBLE);

                    Toast.makeText(MainActivity.this, "Something Went Wrong", Toast.LENGTH_LONG).show();
                }
            });


        } else {
            Log.d(TAG, "onCreate: MSP- Else Statement of Parceable executed");

            list=savedInstanceState.getParcelableArrayList(MOVIES_SAVED);

            mGridAdapter=new GridViewAdapter(MainActivity.this,R.layout.layout_for_grid,list);
            gridView.setAdapter(mGridAdapter);


        }}


    public void showErrorMessage() {

        ErrorMessageDisplay.setVisibility(View.VISIBLE);
        gridView.setVisibility(View.INVISIBLE);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_layout, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int selecteditem = item.getItemId();

        if (selecteditem == R.id.menuitem1) {

            sortbyUserScore();
        }

        return super.onOptionsItemSelected(item);
    }

    public void sortbyUserScore() {

    }

    public void setdata() {
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, "onItemClick: MSP- On Item clcik Executed");

                Results item = (Results) parent.getItemAtPosition(position);

                Intent intent = new Intent(MainActivity.this, MovieDetailsScreen.class);

                intent.putExtra("title", item.getTitle()).
                        putExtra("poster_path", item.getPoster_path()).
                        putExtra("popularity", item.getPopularity()).
                        putExtra("overview", item.getOverview()).
                        putExtra("release_date", item.getRelease_date()).
                        putExtra("vote_average", item.getVote_average());

                startActivity(intent);

            }
        });


    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {


        outState.putParcelableArrayList(MOVIES_SAVED,list );

        super.onSaveInstanceState(outState);
    }
}

