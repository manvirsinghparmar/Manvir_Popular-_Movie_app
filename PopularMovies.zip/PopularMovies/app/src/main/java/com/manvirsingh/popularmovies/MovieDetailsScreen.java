package com.manvirsingh.popularmovies;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MovieDetailsScreen extends AppCompatActivity {

    private TextView movie_title;
    private TextView movie_description;
    private TextView movie_Date_of_release;
    private TextView movie_popularity_rating;
    private ImageView movie_image;
    private TextView movie_vote_average;


    public final static String  TITLE="title";
    public final static String MOVIE_DESCRIPTION="list_index";

    //URL for movie Image
    private final String BASE_URL_IMAGE = "http://image.tmdb.org/t/p/";

    //Query Paramter
    private final static String QUERY_PARAM = "w300";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {


        }

        //Setting details screen layout
        setContentView(R.layout.movie_detail_ui);

        //References to Movie Details
        movie_title = (TextView) findViewById(R.id.movie_Title);
        movie_description = (TextView) findViewById(R.id.movie_Description);
        movie_popularity_rating = (TextView) findViewById(R.id.movie_Popular);
        movie_Date_of_release = (TextView) findViewById(R.id.Release_date);
        movie_image = (ImageView) findViewById(R.id.movie_Poster);
        movie_vote_average = (TextView) findViewById(R.id.movie_user_vote_average);

        //Intent For Receveing Data from Main Activity
        Intent incomingIntent = getIntent();

        //Checking Incoming Intent
        if (incomingIntent != null ){

            //Variables to take data from Incoming Intent for Title,Description & Date of Release
            String new_movie_title = incomingIntent.getStringExtra("title");
            String new_movie_description = incomingIntent.getStringExtra("overview");
            String new_movie_Date_of_release = incomingIntent.getStringExtra("release_date");

            //Variables to take data from Incoming Intent for Popularity & Vote Average
            double new_movie_popularity_rating = incomingIntent.getDoubleExtra("popularity", 0);
            double new_movie_vote_average = incomingIntent.getDoubleExtra("vote_average", 0);

            String path = incomingIntent.getStringExtra("poster_path");

            //Uri to append a base path ahead of relative path
            Uri uri = Uri.parse(BASE_URL_IMAGE).buildUpon().appendEncodedPath(QUERY_PARAM).appendEncodedPath(path).build();


            //Setting the Views
            movie_title.setText(new_movie_title);
            movie_description.setText(new_movie_description);
            movie_Date_of_release.setText(new_movie_Date_of_release);
            movie_popularity_rating.setText(String.valueOf(new_movie_popularity_rating));
            movie_vote_average.setText(String.valueOf(new_movie_vote_average));


            //Loading of MOVIE POSTER into ImageView
            Picasso.get().load(uri).into(movie_image);


        }

    }


}
